#!/system/bin/sh
pkill -9 -f "/data/local/tmp/dfps/dfps"
"/data/local/tmp/dfps/dfps" &
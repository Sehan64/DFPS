#!/system/bin/sh
if pgrep -f "/data/local/tmp/dfps/dfps" >/dev/null; then
    echo "Dynamic FPS is RUNNING."
    echo "--------------------------"
    echo "Current configuration:"
    cat "/data/local/tmp/dfps/dfps.conf"
else
    echo "Dynamic FPS is STOPPED. Initializing..."
    "/data/local/tmp/dfps/dfps" &
    echo "[+] Started."
fi
#!/system/bin/sh
pkill -9 -f "/data/local/tmp/dfps/dfps"
rm -rf /data/local/tmp/dfps
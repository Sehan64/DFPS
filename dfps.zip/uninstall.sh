#!/system/bin/sh
pkill -9 -f "/data/local/tmp/dfps/dfps"
rm -f /data/local/tmp/tx_code.txt
rm -rf /data/local/tmp/dfps